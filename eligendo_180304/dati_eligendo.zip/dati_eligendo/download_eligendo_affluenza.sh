mkdir -p ~/Scrivania/eligendo_affluenza
cd ~/Scrivania/eligendo_affluenza

while [ 1 ]
do
    hour=$(date '+%H')
	minute=$(date '+%M')
	second=$(date '+%S')
	
    curl 'http://elezioni.interno.gov.it/votanti/votanti20180304/votantiCI' -H 'Accept: application/json, text/javascript, */*; q=0.01' -H 'Referer: http://elezioni.interno.gov.it/camera/votanti/20180304/votantiCI' -H 'X-Requested-With: XMLHttpRequest' -H 'User-Agent: Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/64.0.3282.167 Chrome/64.0.3282.167 Safari/537.36' -H 'Content-Type: application/json' --compressed -o ./eligendo_affluenza_180304_$hour$minute$second.json
    
    sleep 300
done

